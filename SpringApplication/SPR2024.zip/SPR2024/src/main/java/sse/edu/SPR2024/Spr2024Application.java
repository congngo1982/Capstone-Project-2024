package sse.edu.SPR2024;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spr2024Application {

	public static void main(String[] args) {
		SpringApplication.run(Spr2024Application.class, args);
	}

}
